function mostrarDiv1() {
    document.getElementById("div1").style.display = "block";
    document.getElementById("div2").style.display = "none";
}

function mostrarDiv2() {
    document.getElementById("div1").style.display = "none";
    document.getElementById("div2").style.display = "block";
}

function mostrarMensajes() {
    console.log("Mensaje de log");
    console.info("Mensaje de información");
    console.error("Mensaje de error");
    alert("¡Botón pulsado!");
}

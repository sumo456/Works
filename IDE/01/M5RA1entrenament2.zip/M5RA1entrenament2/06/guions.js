function insereixImatge() {
    document.getElementById("contenidor_imatge").innerHTML = "<img src='icon-iescv.png' width='200'>";
}


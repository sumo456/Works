-- main.hs
import Exemple

main :: IO ()
main = print (suma 2 3)


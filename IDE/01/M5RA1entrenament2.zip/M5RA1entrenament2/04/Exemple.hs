-- exemple.hs
module Exemple where

suma :: Int -> Int -> Int
suma x y = x + y

